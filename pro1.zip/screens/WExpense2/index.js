import React, {Component} from "react";
import { View, Text, StyleSheet, Button, TextInput,FlatList, Alert ,ImageBackground} from 'react-native';
import TimePicker from 'react-native-simple-time-picker';

import CheckboxGroup from 'react-native-checkbox-group';
import * as Font from 'expo-font';
import {widthPercentageToDP as wp, heightPercentageToDP as hp} from 'react-native-responsive-screen';
import { TouchableOpacity, ScrollView } from 'react-native-gesture-handler';



let arrItem = [];

const week = ["월요일", "화요일", "수요일", "목요일", "금요일", "토요일", "일요일"];
const time = [0,0,0,0,0,0,0];

for(let i = 0; i < week.length; i++){
    arrItem.push({       
        key : i,       
        week: week[i],
        goToWorkHour : "0",
        goToWorkMin : "0",
        offWorkHour : "0",
        offWorkMin: "0",
        time:time[i],
    });
}

class WExpenseScreen2 extends Component {
    constructor(props) {
        super(props);
        
        this.state = {
            totalSelectedTime:arrItem,
            HourlyWage:'0',
            selectedHoursGoToWork:'0',
            selectedMinutesGoToWork:'0',
            selectedHoursOffWork:'0',
            selectedMinutesOffWork:'0',
            time:null,
            WithholdingTax:'0', // 월급*원천세 3.3% 
            HourlyWage:'0', //시급
            Salary:'0', //월급 :시간*시급
            RealSalary:'0' //실질급여 : 월급-원천세
        }
    }

    renderSeparator = () => {  

        return (  
            <View  
                style={{  
                    height: 1,  
                    width: "100%",  
                }}  
            />  
        );  
    };  

    //handling onPress action  
    getListViewItem = (item) => {  
        //Alert.alert(item.key + " : " + item.length);
    }  

    handleChange = (mode, key, hour, min) => {
        if(mode === "goToWork"){
            arrItem[key].goToWorkHour = hour;
            arrItem[key].goToWorkMin = min;
        }else{
            arrItem[key].offWorkHour = hour;
            arrItem[key].offWorkMin = min;
        }
        const goToTime = (arrItem[key].goToWorkHour*60)+arrItem[key].goToWorkMin
        const offTime =  (arrItem[key].offWorkHour*60)+arrItem[key].offWorkMin
        arrItem[key].time = (offTime - goToTime) / 60
        time[key] = arrItem[key].time

        this.setState({
            totalSelectedTime : arrItem,
        })
        //Alert.alert(key + " : " + arrItem[key].goToWorkHour + " : " + arrItem[key].goToWorkMin + " : " + arrItem[key].time);
        //console.log(event.target.value);
    }
    
    updateState(){
        let sumTime=0;
        for(let i=0; i<time.length; i++){
            //console.log(time[i]);
            sumTime = sumTime + time[i]
        }

        const Salary1 = (sumTime * this.state.HourlyWage * 4).toFixed(0) 
        const WithholdingTax1 = (Salary1 * 0.033).toFixed(0) //3.3%
        const RealSalary1 = Salary1 - WithholdingTax1

        this.setState({
            Salary:parseInt(Salary1).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","),
            WithholdingTax:parseInt(WithholdingTax1).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","),
            RealSalary:parseInt(RealSalary1).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
        })
    }

    resetData(){
        this.setState({
            totalSelectedTime:arrItem,
            HourlyWage:'0',
            selectedHoursGoToWork:'0',
            selectedMinutesGoToWork:'0',
            selectedHoursOffWork:'0',
            selectedMinutesOffWork:'0',
            time:null,
            WithholdingTax:'0', // 월급*원천세 3.3% 
            HourlyWage:'0', //시급
            Salary:'0', //월급 :시간*시급
            RealSalary:'0' //실질급여 : 월급-원천세
        })
    }
 

    render(){
        const{selectedHoursGoToWork,selectedMinutesGoToWork, selectedHoursOffWork, selectedMinutesOffWork,
            HourlyWage, WithholdingTax, Salary, RealSalary} = this.state

        return (
//======================================바뀐부분A=========================================
    <View style={styles.image}>
    {/* //======================================바뀐부분A========================================= */}
            <View style={styles.container}>
            <ScrollView>
                <View style={styles.titleArea}>
                    <Text style={styles.textTitle}>인건비 계산하기(단기/일용직)</Text>
                </View>
                <View style={styles.textArea}>
                    <View style={styles.rowView}>
                        <Text style={styles.textStyle}>*시급을 입력해주세요.</Text>
{/* //======================================바뀐부분B========================================= */}
                        <Text style={styles.textStyle2}>(2021년 법정 최저 시급 : 8,720원)</Text>
{/* //======================================바뀐부분B========================================= */}
                    </View>
                    <View style={styles.rowView}>
                        <TextInput
                            value={this.state.HourlyWage}
                            onChangeText={(HourlyWage) => this.setState({HourlyWage})}
                            autoFocus={true}
//======================================바뀐부분C========================================= 
                            placeholder={'8720'}
                            keyboardType={"number-pad"}
//======================================바뀐부분C========================================= 
                            style={styles.textinputStyle}
                            />
                        <Text style={styles.textStyle}>원</Text>
                    </View>
                </View>

{/* //======================================바뀐부분D========================================= */}
                <View style={{marginTop:hp('2%')}}>
                    <Text style={styles.textStyle}>시간 선택하기</Text>
                </View>

{/* //======================================바뀐부분D========================================= */}
                <View style={styles.timeSelectArea}>
                <ScrollView>
            
                <FlatList  
                    data={arrItem}
                    backgroundColor='white'
                    renderItem={({item}) => 
                        <View style={styles.pickerArea}>
                            <CheckboxGroup
                                callback={(selected) => { console.log(selected) }}
                                iconColor={"#00a2dd"}
                                iconSize={wp('10%')}
                                checkedIcon="ios-checkbox-outline"
                                uncheckedIcon="ios-square-outline"
                                checkboxes={[
                                    {
                                    label:<Text style={styles.listText}>{item.week}</Text>,
                                    //label: "월요일", // label for checkbox item
                                    value: 1, // selected value for item, if selected, what value should be sent?
                                    },
                                ]}
//=====================================================바뀐부분E=======================================
                                labelStyle={{
                                    color: '#040525',
                                    marginTop:hp('1%'),
                                    marginLeft:hp('1.,5%'),
                                }}
//=====================================================바뀐부분E=======================================
                                rowStyle={{
                                    flexDirection: 'row'
                                }}
                            />
                            {/*<View style={styles.rowView}>
                                <Text style={styles.item} 
                                    onPress={this.getListViewItem.bind(this, item)}>{item.week}</Text> 
                            </View>*/}
                            <Text style={styles.listText}>출근시간) {item.goToWorkHour}시간 : {item.goToWorkMin}분</Text>
                            <TimePicker
                                key={item.key}
                                selectedHoursGoToWork={selectedHoursGoToWork} //initial Hourse value
                                selectedMinutesGoToWork={selectedMinutesGoToWork} //initial Minutes value
                                onChange={(hours, minutes) =>
                                    //this.setState({ selectedHoursGoToWork: hours, selectedMinutesGoToWork: minutes })}
                                    this.handleChange('goToWork', item.key, hours, minutes)
                                }
                            />
                            <Text style={styles.listText}>퇴근시간) {item.offWorkHour}시간 : {item.offWorkMin}분</Text>
                            <TimePicker
                                selectedHoursOffWork={selectedHoursOffWork} //initial Hourse value
                                selectedMinutesOffWork={selectedMinutesOffWork} //initial Minutes value
                                onChange={(hours, minutes) =>
                                    //this.setState({ selectedHoursOffWork: hours, selectedMinutesOffWork: minutes })}
                                    this.handleChange('offWork', item.key, hours, minutes)
                                }
                            />
{/* //============================================바뀐부분F====================================== */}
{/* 여기 있던 <Text>ㅡㅡㅡㅡㅡㅡㅡㅡㅡㅡ</Text> 없어짐 */}
{/* //============================================바뀐부분F====================================== */}
                        </View>
                        }  
                    ItemSeparatorComponent={this.renderSeparator}  
                />  
                
                {/* <View>
                    <Text>시간선택</Text>
                </View>
                <TimePicker
                    selectedHours={selectedHours}
                    //initial Hourse value
                    selectedMinutes={selectedMinutes}
                    //initial Minutes value
                    onChange={(selectedHours) => this.setState({selectedHours})}
                    onChange={(selectedMinutes) => this.setState({selectedMinutes})}
                /> */}
                </ScrollView>
                </View>

                <View style={styles.buttonArea}>
                    <TouchableOpacity
                        style={styles.button}
                        onPress={()=>{this.updateState()}}>
                        <Text style={styles.buttonTitle}>인건비 계산하기</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        style={styles.buttonReset}
                        onPress={()=>{this.resetData()}}>
                    <Text style={styles.buttonResetTitle}>초기화</Text>       
                    </TouchableOpacity>
                </View>

                <View style={styles.resultArea}>
                    <Text style={styles.textStyle}>* 인건비 계산 결과</Text>
                    <Text style={styles.textResultStyle}>월 급여 : {Salary} 원</Text>    
                    <Text style={styles.textResultStyle}>원천세 : {WithholdingTax} 원</Text>
                    <Text style={styles.textResultStyle}>실질 급여 : {RealSalary} 원</Text>
                </View> 

                
            </ScrollView>
            </View>
            </View>
        );
    }
    
}

export default WExpenseScreen2;

//========================================바뀐부분 스타일===================================

const styles = StyleSheet.create({
    container: { 
        padding:wp('4.5%'), 
        width: "100%",
        height: "100%",
        backgroundColor: 'white',
        borderTopRightRadius:wp('13%'),
        borderTopLeftRadius:wp('13%'),
    },
    rowView : {flexDirection:"row"},
    image:{ 
        width: "100%", height: "100%", 
        backgroundColor:'#7085DF',
        alignItems: 'center', justifyContent:"center",
    },
    buttonArea: {
        alignItems:"center",
        width: '100%', height: hp('10%'),
        marginBottom:hp('12%'),
    },
    titleArea:{
      alignItems:"center"
    },
    button: {
        backgroundColor: "#7085DF",
        width:wp('90%'), height: hp('5.5%'),
        justifyContent: 'center', alignItems:"center",
        borderRadius:wp('6%'),
        marginTop:hp('2%'),
    },
    buttonReset: {
        backgroundColor: "#040525",
        width:wp('90%'), height: hp('5.5%'),
        justifyContent: 'center', alignItems:"center",
        borderRadius:wp('6%'),
        marginTop:hp('1%'),
    },
    buttonTitle: {
        color: 'white',
        fontFamily:"NanumSquare",
        fontSize: wp('4.8%'),
    },  
    buttonResetTitle: {
        color: 'white',
        fontFamily:"NanumSquare",
        fontSize: wp('4.8%'),
    },  
    textTitle:{
        fontSize: wp('5.55%'),
        fontFamily:"NanumSquareB",
        marginBottom:hp('2%'),
        marginTop:hp('2%'),
        color:'#040525',
    },
    textArea:{
        marginTop:hp('2%'),
        marginBottom:hp('2%'),
        marginLeft:wp('1.5%')
    },
    textStyle:{
        fontSize: wp('4.2%'),
        fontFamily:"NanumSquare",
        color:'#040525',
        marginTop:wp('1%'),
        marginBottom:wp('1.5%'),
        marginRight:wp('2%'),
    },  
    textStyle2:{
        fontSize:wp('3.35%'),
        fontFamily:"NanumSquare",
        marginTop:wp('1.5%'),
        marginBottom:wp('1.5%'),
        marginRight:wp('2%'),
        color:'#040525',
    },  
    textinputStyle:{
      fontSize: wp('4.2%'),
      fontFamily:"NanumSquare",
      marginLeft:wp('3%'),
      width:wp('35%'), height:hp('4.5%'), textAlign:"center", justifyContent:"center",
      borderBottomWidth:hp('0.5%'),
      borderBottomColor:'#7085DF'
  },
    timeSelectArea:{
        marginTop:hp('1%'),
        marginBottom:hp('5%'),
        height:hp('40%'),
        borderColor:'#7085DF', borderWidth:wp('0.5%'), 
        borderRadius:wp('4%'),
        padding:wp('2%')
    },  
    pickerArea:{
        padding:wp('2%'), 
        borderBottomColor:'#7085DF', 
        borderBottomWidth:hp('0.1%')
    },
    textResultStyle:{
      fontSize:wp('5.05%'),
      fontFamily:"NanumSquareB",
      marginLeft:wp('3%'),
      marginTop:wp('1%'),
      marginBottom:wp('1.5%'),
      marginRight:wp('2%'),
    },
    resultArea:{
        marginBottom:hp('5%')
    },
    listText1:{
        fontSize:wp('3.6%'),
        fontFamily:"NanumSquare",
        marginTop:hp('0.5%'),
        color:'#040525',
    },  
    listText:{
        fontSize:wp('3.6%'),
        fontFamily:"NanumSquare",
        color:'#040525',
    },  
});
